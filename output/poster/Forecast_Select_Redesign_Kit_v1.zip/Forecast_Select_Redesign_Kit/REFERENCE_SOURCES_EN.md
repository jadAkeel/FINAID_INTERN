# Supporting research and model references

These are supporting references retained during the approved poster preparation. They are not extra poster text, a new literature review, independent model benchmarks, or a requirement to add citations to the artwork. Preserve the approved poster copy if a source offers additional variants. Do not introduce a new checkpoint or a new claim during a visual redesign.

## Research context

The local final locked evaluation protocol records 48 forecast origins, 268–315. Displayed results are Uptrend 445/720 = 61.81%; Active selector 492/807 = 60.97%; Prior-only rule 436/720 = 60.56%. The approximately 62% headline rounds the Uptrend score. The policy was fixed before testing, with walk-forward refits using only earlier available training outcomes. Each future target was unavailable at prediction time; earlier matured labels may enter later refits.

This is a revised historical-data study. It does not demonstrate trading profit, live deployment performance or active-selector superiority. The selected adaptive model supports Up and Down calls; that design choice should not be described as a comparative accuracy win. Macroeconomic framing comes from the original research plan. Indicator identities remain anonymous.

Internal evidence locations (for the project owner; files are not included because the design package does not need training data or a repository checkout):
- research/final_locked_evaluation/PROTOCOL.md
- metrics/locked_result.json
- docs/reference/original_research_plan.md

## Primary model references retained during poster preparation

Sizes below concern parameters and named checkpoints, not file sizes or runtime requirements. Sources were retained in the existing poster evidence; no new web re-verification was performed just to package this brief. Model catalogue entries are not all components of Forecast Select.

| Model | Display size | Primary reference |
| --- | --- | --- |
| Nemotron 3.5 Transcribe | 30B class; audio encoders complicate an exact total | https://huggingface.co/nvidia/NVIDIA-Nemotron-3.5-Transcribe-30B-A4B |
| Whisper Tiny / Base | 39M / 74M | https://github.com/openai/whisper |
| Qwen3-ASR | 1.7B checkpoint | https://huggingface.co/Qwen/Qwen3-ASR-1.7B |
| Laya Multilingual | 322M | https://huggingface.co/convaiinnovations/laya-multilingual/raw/main/README.md |
| GLiNER2.5 Multi-Decide | 287M, rounded from 287355159 | https://huggingface.co/api/models/fastino/GLiNER2.5-multi-Decide |
| Kev-4B | 4B | https://github.com/jaredpalmer/kev |
| Fish Audio Drama 3 | 35B total, 3B active | https://huggingface.co/fishaudio/drama-3 |
| Qwen3-TTS | 1.7B checkpoint | https://huggingface.co/Qwen/Qwen3-TTS-12Hz-1.7B-CustomVoice |
| Pocket TTS | 100M standard model | https://github.com/kyutai-labs/pocket-tts |
| PaddleOCR-VL 1.6 | 0.9B | https://huggingface.co/PaddlePaddle/PaddleOCR-VL-1.6 |
| Unlimited OCR 2 | ~3B per model-card size; finer 3.34B not established | https://huggingface.co/baidu/Unlimited-OCR-2 |
| Falcon OCR Arabic | 270M | https://falcon-lm.github.io/blog/falcon-ocr/ |
| EmbeddingGemma 2 | 740M total; 270M text backbone | https://huggingface.co/google/embeddinggemma-2 |
| SAM 3 | ~860M, rounded from 859922360 | https://huggingface.co/api/models/facebook/sam3 |
| YOLO26n / YOLO26s | 2.4M / 9.5M fused detection model | https://docs.ultralytics.com/models/yolo26/ |
| RF-DETR Nano | 30.5M detection model | https://github.com/roboflow/rf-detr |
| TabPFN 3.5 | 220M | https://storage.googleapis.com/prior-labs-tabpfn-public/reports/tabpfn-v3.5-report.pdf |
| TabICL v2 | ~28M, range 27.55M–28.54M in NVIDIA implementation | https://nvidia.github.io/structured-data-models/api/generated/sdm.models.TabICLv2.html |
| Timestral | 209M standard | https://github.com/mistralai/timestral |
| Chronos-2 | 120M | https://huggingface.co/amazon/chronos-2 |
