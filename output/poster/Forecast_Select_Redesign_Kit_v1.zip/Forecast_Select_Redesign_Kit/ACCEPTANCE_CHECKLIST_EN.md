# Acceptance and comparison checklist

Use the same brief and the same reference files for each candidate. Score visual quality only after the mandatory checks pass. Keep this checklist outside the artwork.

## Mandatory checks

- [ ] One English portrait poster; final document trim exactly 841 × 1190 mm. For a raster-only concept, actual pixels and any ratio limitation are disclosed.
- [ ] FORECAST SELECT; correct subtitle and macroeconomic research description; COHORT 3 AI TRACK without a slash.
- [ ] Original Khwarizme logo, complete and undistorted; Poppins and approved brand colours.
- [ ] Consistent left edges and column insets; no clipping, overlaps or microscopic labels.
- [ ] 50 anonymous indicators; 316 monthly observations; 15–20 selected calls per month; February 2000 – May 2026.
- [ ] All five sections in the research-to-conclusion narrative; chosen model name, method and rationale intact.
- [ ] Workflow order and all five labels intact; any plotted marks are clearly conceptual, not invented empirical results.
- [ ] ≈62% immediately attributed to Uptrend baseline 61.81%; 445/720 and 48 months remain.
- [ ] Three-row table intact: Uptrend baseline 61.81% / 720; Active selector 60.97% / 807; Prior-only rule 60.56% / 720.
- [ ] Unseen-future-outcome statement, fixed-policy preregistration, past-only walk-forward training, revised-data caveat, no-trading-return interpretation and lack of active superiority remain.
- [ ] All eight model families, their parenthetical labels, task descriptions and every approved model/size row appear. Compare row by row with POSTER_CONTENT_EN.txt.
- [ ] Approximate sizes and 30B class retained. ASR/STT and TTS correctly distinguished. Catalogue not presented as the project's components.
- [ ] Excluded rows have not returned; Kev-4B remains. No invented claims, authors, QR codes or benchmarks.
- [ ] Parameter legend, catalogue scope, website and November 2026 footer remain.
- [ ] Export description is truthful: editable elements actually editable; exact-size PDF and embedded fonts checked if a print-ready file is claimed. A raster concept is labelled as such outside the artwork.

## Visual comparison (0–5 each, only after mandatory compliance)

| Criterion | What to judge |
| --- | --- |
| Research narrative | Problem, approach, workflow and evidence are quickly understood. |
| Hierarchy | Clear title and section order; ≈62% has a clear attribution. |
| Typography and readability | Comfortable actual-size reading, clean names/sizes, balanced wrapping. |
| Grid and spacing | Consistent left alignment, calm margins, deliberate use of whitespace. |
| Diagram and catalogue | Helpful conceptual workflow; complete eight-family catalogue without overwhelming the research. |
| Brand and craft | Original logo and colours, crisp execution, coherent visual character. |

A candidate with missing or altered content needs correction before replacing the current version, regardless of its visual score. Keep the current accepted poster as the comparison baseline.
